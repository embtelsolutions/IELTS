@extends('admin.layout')
<style>
	.p-body {
    padding-left: 18px!important;
    padding-right: 18px!important;
}
</style>
@section('content')
  <div class="mt-2 mb-4">
    {{-- <h2 class="text-white pb-2">Welcome back, {{Auth::guard('admin')->user()->first_name}} {{Auth::guard('admin')->user()->last_name}}!</h2> --}}
  </div>
  <div class="page-header">
	<h4 class="page-title">Tests</h4>
	<ul class="breadcrumbs">
	   <li class="nav-home">
		  <a href="{{route('teacher.index')}}">
		  <i class="flaticon-home"></i>
		  </a>
	   </li>
	   <li class="separator">
		  <i class="flaticon-right-arrow"></i>
	   </li>
	   <li class="nav-item">
		  <a href="#">Test Management</a>
	   </li>
	   <li class="separator">
		  <i class="flaticon-right-arrow"></i>
	   </li>
	   <li class="nav-item">
		  <a href="#">Create Test</a>
	   </li>
	</ul>
 </div>

 <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">
            <div class="row">
                <div class="col-lg-10">
                    <div class="card-title">Create Test</div>
                </div>
                <div class="col-lg-2">
                   
                </div>
            </div>
        </div>
        <div class="card-body p-body pt-5 pb-4">
			<form action="" method="post">
				<div class="row">
					<div class="form-group col-md-4">
						<label for="">Test Title*</label>
						<input id="" type="text" class="form-control" name="title" value="" placeholder="Enter title">
						<p id="err_title" class="mb-0 text-danger em"></p>
					</div>
					<div class="form-group col-md-4">
						<label for="">Time*</label>
						<input type="text" id="" class="form-control " name="test_time" placeholder="Enter description">
						<p id="err_test_time" class="mb-0 text-danger em"></p>
					</div>
					<div class="form-group col-md-4">
						<label for="">Instruction*</label>
						<textarea id="" class="form-control " name="inst_test" data-height="200" placeholder="Enter instruction" rows="4" cols="50"></textarea>
						<p id="err_inst_test" class="mb-0 text-danger em"></p>
					</div>
				</div>

				
				<div class="row">
					<!-- Test type  Practice/Full-->
					<div class="form-group col-md-4">
						<label for="">Test Type</label>		
						<select class="form-control mg-10" id="test_type" name="test_type">
							<option>Practice</option>
							<option>Full</option>
						</select>
						<p id="err_test_type" class="mb-0 text-danger em"></p>		
					</div>
					<!---/end test type-->

					<!-- Module type -->
					<div class="form-group col-md-4">
						<label for="">Module Type</label>		
						<select class="form-control mg-10" id="module_type" name="module_type">
							<option>Reading</option>
							{{-- <option>Listening</option>
							<option>Writing</option>
							<option>Speaking</option> --}}
						</select>
						<p id="err_module_type" class="mb-0 text-danger em"></p>		
					</div>
					<div class="form-group col-md-4">
						<label for="">Time Limit For each section</label>		
						<input type="text" id="module_time" class="form-control " name="module_time" placeholder="Enter time">
						<p id="err_module_time" class="mb-0 text-danger em"></p>		
					</div>
					<!---/end Module type-->					
				</div>
				
				<hr style="color: white; background-color:white" />

				<!--practice test form fields--->
<!---reading form --->
			<div id="reading_form" >
				<div class="col-lg-10">
                    <div class="card-title">Practice Test Reading</div>
                </div>
				
				<div class="row">
		
					<div class="form-group col-md-4">
						<label for="">Instruction*</label>
						<textarea id="inst_module" class="form-control " name="inst_module" data-height="200" placeholder="Enter Instruction" rows="4" cols="50"></textarea>
						<p id="err_inst_module" class="mb-0 text-danger em"></p>
					</div>
					<div class="form-group col-md-4">
						<label for="">Section Type</label>		
						<select class="form-control mg-10" id="section_type" name="test_type">
							<option>Paragraph</option>
							<option>Image</option>
						</select>
						<p id="err_section_type" class="mb-0 text-danger em"></p>		
					</div>
							
				</div>
				<!--paragraph field--->	
				<div id="paragraph" class="">
					<hr style="color: white; background-color:white" />

					<div class="row">
						<div class="col-lg-10">
							<div class="card-title">Paragraph</div>
						</div>
						<div class="form-group col-md-6">
							<label for="">Instruction*</label>
							<textarea id="inst_module" class="form-control " name="inst_module" data-height="200" placeholder="Enter Instruction" rows="4" cols="50"></textarea>
							<p id="err_inst_module" class="mb-0 text-danger em"></p>
						</div>
					</div>
						<hr style="color: white; background-color:white" />
						
					<div class="row">
						<!--- question one--->
						<div class="form-group col-md-4">
							<label for="">Question 1*</label>
							<input id="" type="text" class="form-control" name="que_one" value="" placeholder="Enter question">
							<p id="err_que_one" class="mb-0 text-danger em"></p>
							<br>
							<select class="form-control mg-10" id="que_one_type" name="que_one_type">
								<option>MCQ</option>
								<option>Blank</option>
							</select>
						</div>
						<!--if question is mcq--->
						<div class="form-group col-md-4" id="mcq_option_one_div">
							<label for="">MCQ *</label>
							<textarea id="mcq_option_one" class="form-control " name="mcq_option_one" data-height="200" placeholder="Enter option" rows="4" cols="50"></textarea>
							<p id="err_mcq_option_one" class="mb-0 text-danger em"></p>
						</div>
						<div class="form-group col-md-4" id="ans_mcq_one_div">
							<label for="">Answer*</label>
							<input id="ans_mcq_one" type="text" class="form-control" name="ans_mcq_one" value="" placeholder="Enter Answer">
							<p id="err_ans_one" class="mb-0 text-danger em"></p>
						</div>
						<!----end mcq--->

						<!----if question is blank--->
						<div class="form-group col-md-4 d-none" id="ans_blank_one_div">
							<label for="">Answer*</label>
							<input id="ans_blank_one" type="text" class="form-control" name="ans_blank_one" value="" placeholder="Enter Answer">
							<p id="err_ans_two" class="mb-0 text-danger em"></p>
						</div>
						<!----end question is blank--->

					</div>
					<hr style="color: white; background-color:white" />
					<div class="row">
						<div class="form-group col-md-4">
							<label for="">Question 2*</label>
							<input id="" type="text" class="form-control" name="que_two" value="" placeholder="Enter question">
							<p id="err_que_two" class="mb-0 text-danger em"></p>
							<br>
							<select class="form-control mg-10" id="que_two_type" name="que_two_type">
								<option>MCQ</option>
								<option>Blank</option>
							</select>
						</div>
						<div class="form-group col-md-4" id="mcq_option_two_div">
							<label for="">MCQ *</label>
							<textarea id="mcq_option_two" class="form-control " name="mcq_option_two" data-height="200" placeholder="Enter option" rows="4" cols="50"></textarea>
							<p id="err_mcq_option_two" class="mb-0 text-danger em"></p>
						</div>
						<div class="form-group col-md-4" id="ans_mcq_two_div">
							<label for="">Answer*</label>
							<input id="ans_mcq_two" type="text" class="form-control" name="ans_mcq_two" value="" placeholder="Enter Answer">
							<p id="err_ans_two" class="mb-0 text-danger em"></p>
						</div>
						<!----if question is blank--->
						<div class="form-group col-md-4 d-none" id="ans_blank_two_div">
							<label for="">Answer*</label>
							<input id="" type="text" class="form-control" name="ans_blank_two" value="" placeholder="Enter Answer">
							<p id="err_ans_two" class="mb-0 text-danger em"></p>
						</div>
						<!----end if question is blank--->
					</div>

					<hr style="color: white; background-color:white" />
					<div class="row">
						<div class="form-group col-md-4">
							<label for="">Question 3*</label>
							<input id="" type="text" class="form-control" name="que_three" value="" placeholder="Enter question">
							<p id="err_que_three" class="mb-0 text-danger em"></p>
							<br>
							<select class="form-control mg-10" id="que_three_type" name="que_three_type">
								<option>MCQ</option>
								<option>Blank</option>
							</select>
						</div>
						<div class="form-group col-md-4" id="mcq_option_three_div">
							<label for="">MCQ *</label>
							<textarea id="mcq_option_three" class="form-control " name="mcq_option_three" data-height="200" placeholder="Enter option" rows="4" cols="50"></textarea>
							<p id="err_mcq_option_three" class="mb-0 text-danger em"></p>
						</div>
						<div class="form-group col-md-4" id="ans_mcq_three_div">
							<label for="">Answer*</label>
							<input id="ans_mcq_three" type="text" class="form-control" name="ans_mcq_three" value="" placeholder="Enter Answer">
							<p id="err_ans_mcq_three" class="mb-0 text-danger em"></p>
						</div>
						<!----if question is blank--->
						<div class="form-group col-md-4 d-none" id="ans_blank_three_div">
							<label for="">Answer*</label>
							<input id="ans_blank_three" type="text" class="form-control" name="ans_blank_three" value="" placeholder="Enter Answer">
							<p id="err_ans_three" class="mb-0 text-danger em"></p>
						</div>
						<!----end if question is blank--->
					</div>


					<hr style="color: white; background-color:white" />
					<div class="row">
						<div class="form-group col-md-4">
							<label for="">Question 4*</label>
							<input id="que_four" type="text" class="form-control" name="que_four" value="" placeholder="Enter question">
							<p id="err_que_three" class="mb-0 text-danger em"></p>
							<br>
							<select class="form-control mg-10" id="que_four_type" name="que_four_type">
								<option>MCQ</option>
								<option>Blank</option>
							</select>
						</div>
						<div class="form-group col-md-4" id="mcq_option_four_div">
							<label for="">MCQ *</label>
							<textarea id="mcq_option_four" class="form-control " name="mcq_option_four" data-height="200" placeholder="Enter option" rows="4" cols="50"></textarea>
							<p id="err_mcq_option_four" class="mb-0 text-danger em"></p>
						</div>
						<div class="form-group col-md-4" id="ans_mcq_four_div">
							<label for="">Answer*</label>
							<input id="ans_mcq_four" type="text" class="form-control" name="ans_mcq_four" value="" placeholder="Enter Answer">
							<p id="err_ans_mcq_four" class="mb-0 text-danger em"></p>
						</div>
						<!----if question is blank--->
						<div class="form-group col-md-4 d-none" id="ans_blank_four_div">
							<label for="">Answer*</label>
							<input id="" type="text" class="form-control" name="ans_blank_four" value="" placeholder="Enter Answer">
							<p id="err_ans_four" class="mb-0 text-danger em"></p>
						</div>
						<!----end if question is blank--->
					</div>
				</div>
				<!--end Paragraph test--->
				<!--Start image test--->
				<div id="image" class="d-none">
					<hr style="color: white; background-color:white" />

					<div class="row">
						<div class="col-lg-10">
							<div class="card-title">Image</div>
						</div>
						<div class="form-group col-md-6">
							<label for="">Instruction*</label>
							<textarea id="img_inst_module" class="form-control " name="img_inst_module" data-height="200" placeholder="Enter Instruction" rows="4" cols="50"></textarea>
							<p id="err_inst_module" class="mb-0 text-danger em"></p>
						</div>
						<div class="form-group col-md-4">
							<label for="">Image*</label>
							<input type="file" accept="Image/*" id="img_reading" class="form-control " name="img_reading" placeholder="Enter description" data-height="200" readonly>
							<p id="err_image_reading" class="mb-0 text-danger em"></p>
						 </div>
					</div>	

					<hr style="color: white; background-color:white" />

					<div class="row">
						<div class="form-group col-md-4">
							<label for="">Question 1*</label>
							<input id="img_que_one" type="text" class="form-control" name="img_que_one" value="" placeholder="Enter question">
							<p id="err_img_que_one" class="mb-0 text-danger em"></p>
							<br>
							<select class="form-control mg-10" id="img_que_one_type" name="img_que_one_type">
								<option>MCQ</option>
								<option>Blank</option>
							</select>
						</div>
						<div class="form-group col-md-4" id="img_mcq_option_one_div">
							<label for="">MCQ *</label>
							<textarea id="img_mcq_option_one" class="form-control " name="img_mcq_option_one" data-height="200" placeholder="Enter option" rows="4" cols="50"></textarea>
							<p id="err_img_mcq_option_one" class="mb-0 text-danger em"></p>
						</div>
						<div class="form-group col-md-4" id="img_ans_mcq_one_div">
							<label for="">Answer*</label>
							<input id="img_ans_mcq_one" type="text" class="form-control" name="img_ans_mcq_one" value="" placeholder="Enter Answer">
							<p id="err_img_ans_mcq_four" class="mb-0 text-danger em"></p>
						</div>
						<!----if question is blank--->
						<div class="form-group col-md-4 d-none" id="img_ans_blank_one_div">
							<label for="">Answer*</label>
							<input id="img_ans_one" type="text" class="form-control" name="img_ans_one" value="" placeholder="Enter Answer">
							<p id="err_img_ans_one" class="mb-0 text-danger em"></p>
						</div>
						<!----end if question is blank--->
					</div>

					<hr style="color: white; background-color:white" />

					<div class="row">
						<div class="form-group col-md-4">
							<label for="">Question 2*</label>
							<input id="img_que_two" type="text" class="form-control" name="img_que_two" value="" placeholder="Enter question">
							<p id="err_img_que_two" class="mb-0 text-danger em"></p>
							<br>
							<select class="form-control mg-10" id="img_que_two_type" name="img_que_two_type">
								<option>MCQ</option>
								<option>Blank</option>
							</select>
						</div>
						<div class="form-group col-md-4" id="img_mcq_option_two_div">
							<label for="">MCQ *</label>
							<textarea id="img_mcq_option_two" class="form-control " name="img_mcq_option_two" data-height="200" placeholder="Enter option" rows="4" cols="50"></textarea>
							<p id="err_image_mcq_option_two" class="mb-0 text-danger em"></p>
						</div>
						<div class="form-group col-md-4" id="img_ans_mcq_two_div">
							<label for="">Answer*</label>
							<input id="img_ans_mcq_two" type="text" class="form-control" name="img_ans_mcq_two" value="" placeholder="Enter Answer">
							<p id="err_img_ans_mcq_four" class="mb-0 text-danger em"></p>
						</div>
						<!----if question is blank--->
						<div class="form-group col-md-4 d-none" id="img_ans_blank_two_div">
							<label for="">Answer*</label>
							<input id="img_ans_two" type="text" class="form-control" name="img_ans_two" value="" placeholder="Enter Answer">
							<p id="err_img_ans_two" class="mb-0 text-danger em"></p>
						</div>
						<!----end if question is blank--->
					</div>
					<hr style="color: white; background-color:white" />

					<div class="row">
						<div class="form-group col-md-4">
							<label for="">Question 3*</label>
							<input id="img_que_three" type="text" class="form-control" name="img_que_three" value="" placeholder="Enter question">
							<p id="err_img_que_two" class="mb-0 text-danger em"></p>
							<br>
							<select class="form-control mg-10" id="img_que_three_type" name="img_que_three_type">
								<option>MCQ</option>
								<option>Blank</option>
							</select>
						</div>
						<div class="form-group col-md-4" id="img_mcq_option_three_div">
							<label for="">MCQ *</label>
							<textarea id="img_mcq_option_three" class="form-control " name="img_mcq_option_three" data-height="200" placeholder="Enter option" rows="4" cols="50"></textarea>
							<p id="err_image_mcq_option_three" class="mb-0 text-danger em"></p>
						</div>
						<div class="form-group col-md-4" id="img_ans_mcq_three_div">
							<label for="">Answer*</label>
							<input id="img_ans_mcq_three" type="text" class="form-control" name="img_ans_mcq_three" value="" placeholder="Enter Answer">
							<p id="err_img_ans_mcq_three" class="mb-0 text-danger em"></p>
						</div>
						<!----if question is blank--->
						<div class="form-group col-md-4 d-none" id="img_ans_blank_three_div">
							<label for="">Answer*</label>
							<input id="img_ans_three" type="text" class="form-control" name="img_ans_three" value="" placeholder="Enter Answer">
							<p id="err_img_ans_three" class="mb-0 text-danger em"></p>
						</div>
					</div>
						<!----end if question is blank--->

						<hr style="color: white; background-color:white" />

						<div class="row">
							<div class="form-group col-md-4">
								<label for="">Question 4*</label>
								<input id="img_que_four" type="text" class="form-control" name="img_que_four" value="" placeholder="Enter question">
								<p id="err_img_que_four" class="mb-0 text-danger em"></p>
								<br>
								<select class="form-control mg-10" id="img_que_four_type" name="img_que_four_type">
									<option>MCQ</option>
									<option>Blank</option>
								</select>
							</div>
							<div class="form-group col-md-4" id="img_mcq_option_four_div">
								<label for="">MCQ *</label>
								<textarea id="img_mcq_option_four" class="form-control " name="img_mcq_option_four" data-height="200" placeholder="Enter option" rows="4" cols="50"></textarea>
								<p id="err_image_mcq_option_four" class="mb-0 text-danger em"></p>
							</div>
							<div class="form-group col-md-4" id="img_ans_mcq_four_div">
								<label for="">Answer*</label>
								<input id="img_ans_mcq_four" type="text" class="form-control" name="img_ans_mcq_four" value="" placeholder="Enter Answer">
								<p id="err_img_ans_mcq_four" class="mb-0 text-danger em"></p>
							</div>
							<!----if question is blank--->
							<div class="form-group col-md-4 d-none" id="img_ans_blank_four_div">
								<label for="">Answer*</label>
								<input id="img_ans_four" type="text" class="form-control" name="img_ans_four" value="" placeholder="Enter Answer">
								<p id="err_img_ans_four" class="mb-0 text-danger em"></p>
							</div>
						</div>
					</div>				
				</div>
				<!--end image test--->

			<!--end Practice test form fields--->	
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary">Cancel</button>
				<button id="" type="button" class="btn btn-primary">Submit</button>
			 </div>
			</form>
          </div>
        </div>
      </div>
    </div>
  </div>
@endsection
@push('after-script')
<script>
	$(document).ready(function(){
		// alert(0);
	
		$('#section_type').change(function() {
	// $(this).val() will work here
			
      if($('#section_type').val() == "Paragraph"){
            $('#paragraph').removeClass('d-none');
            $('#image').addClass('d-none');
      }else{
		 $('#paragraph').addClass('d-none');
		 $('#image').removeClass('d-none');
		 
      }
   });
		// question one_type   
	$('#que_one_type').change(function() {
      if($('#que_one_type').val() == "Blank"){
            $('#ans_blank_one_div').removeClass('d-none');
			$('#mcq_option_one_div').addClass('d-none');
			$('#ans_mcq_one_div').addClass('d-none');
      }else{
		 $('#ans_blank_one_div').addClass('d-none');
		 $('#mcq_option_one_div').removeClass('d-none');
		 $('#ans_mcq_one_div').removeClass('d-none'); 
      }
   });

   // question two  
   $('#que_two_type').change(function() {
      if($('#que_two_type').val() == "Blank"){
            $('#ans_blank_two_div').removeClass('d-none');
			$('#mcq_option_two_div').addClass('d-none');
			$('#ans_mcq_two_div').addClass('d-none');
      }else{
		 $('#ans_blank_two_div').addClass('d-none');
		 $('#mcq_option_two_div').removeClass('d-none');
		 $('#ans_mcq_two_div').removeClass('d-none'); 
      }
   });
    // question three  
	$('#que_three_type').change(function() {
      if($('#que_three_type').val() == "Blank"){
            $('#ans_blank_three_div').removeClass('d-none');
			$('#mcq_option_three_div').addClass('d-none');
			$('#ans_mcq_three_div').addClass('d-none');
      }else{
		 $('#ans_blank_three_div').addClass('d-none');
		 $('#mcq_option_three_div').removeClass('d-none');
		 $('#ans_mcq_three_div').removeClass('d-none'); 
      }
	});

	// question four  
	$('#que_four_type').change(function() {
      if($('#que_four_type').val() == "Blank"){
            $('#ans_blank_four_div').removeClass('d-none');
			$('#mcq_option_four_div').addClass('d-none');
			$('#ans_mcq_four_div').addClass('d-none');
      }else{
		 $('#ans_blank_four_div').addClass('d-none');
		 $('#mcq_option_four_div').removeClass('d-none');
		 $('#ans_mcq_four_div').removeClass('d-none'); 
      }
	});
	ImageTypeQuetion();
	function ImageTypeQuetion(){

			// question one_type   
	$('#img_que_one_type').change(function() {
      if($('#img_que_one_type').val() == "Blank"){
            $('#img_ans_blank_one_div').removeClass('d-none');
			$('#img_mcq_option_one_div').addClass('d-none');
			$('#img_ans_mcq_one_div').addClass('d-none');
      }else{
		 $('#img_ans_blank_one_div').addClass('d-none');
		 $('#img_mcq_option_one_div').removeClass('d-none');
		 $('#img_ans_mcq_one_div').removeClass('d-none'); 
      }
   });

   // question two  
   $('#img_que_two_type').change(function() {
      if($('#img_que_two_type').val() == "Blank"){
            $('#img_ans_blank_two_div').removeClass('d-none');
			$('#img_mcq_option_two_div').addClass('d-none');
			$('#img_ans_mcq_two_div').addClass('d-none');
      }else{
		 $('#img_ans_blank_two_div').addClass('d-none');
		 $('#img_mcq_option_two_div').removeClass('d-none');
		 $('#img_ans_mcq_two_div').removeClass('d-none'); 
      }
   });
    // question three  
	$('#img_que_three_type').change(function() {
      if($('#img_que_three_type').val() == "Blank"){
            $('#img_ans_blank_three_div').removeClass('d-none');
			$('#img_mcq_option_three_div').addClass('d-none');
			$('#img_ans_mcq_three_div').addClass('d-none');
      }else{
		 $('#img_ans_blank_three_div').addClass('d-none');
		 $('#img_mcq_option_three_div').removeClass('d-none');
		 $('#img_ans_mcq_three_div').removeClass('d-none'); 
      }
	});

	// question four  
	$('#img_que_four_type').change(function() {
      if($('#img_que_four_type').val() == "Blank"){
            $('#img_ans_blank_four_div').removeClass('d-none');
			$('#img_mcq_option_four_div').addClass('d-none');
			$('#img_ans_mcq_four_div').addClass('d-none');
      }else{
		 $('#img_ans_blank_four_div').addClass('d-none');
		 $('#img_mcq_option_four_div').removeClass('d-none');
		 $('#img_ans_mcq_four_div').removeClass('d-none'); 
      }
	});

	}

   	})

</script>
@endpush